<template>
  <div class="channel-edit">
    <van-cell style="text-align: center" title="编辑频道"> </van-cell>
    <van-cell title="我的频道">
      <template #default>
        <van-button
          class="edit-btn"
          plain
          round
          size="mini"
          type="danger"
          @click="isEdit = !isEdit"
          >{{ isEdit ? "完成" : "编辑" }}</van-button
        >
      </template>
    </van-cell>
    <van-grid :gutter="10">
      <van-grid-item
        class="channel-item"
        v-for="(value, index) in userHeaderInfo"
        :key="value.id"
        @click="onMy"
      >
        <template #icon v-if="isEdit">
          <van-icon name="clear"></van-icon>
        </template>
        <template #text>
          <span class="text" :class="{ active: active === index }">{{
            value.name
          }}</span>
        </template>
      </van-grid-item>
    </van-grid>
    <van-cell title="推荐频道"> </van-cell>
    <van-grid class="recommed-channel" direction="horizontal" :gutter="10">
      <van-grid-item
        v-for="value in recommendChannels"
        :key="value.id"
        icon="plus"
        class="channel-item"
        @click="addChannel(value)"
      >
        <template #text>
          <span class="text">{{ value.name }}</span>
        </template></van-grid-item
      >
    </van-grid>
  </div>
</template>

<script>
import { fetchAllCitys } from "@/api/channel";
import { differenceBy } from "@/utils/lodash";
export default {
  name: "channeledit",
  props: {
    userHeaderInfo: {
      type: Array,
      default: () => [],
    },
    active: {
      type: Number,
      required: true,
    },
  },
  data() {
    return {
      allChannels: [],
      isEdit: false,
    };
  },
  created() {
    this.fetchAllCity();
  },
  computed: {
    recommendChannels() {
      return differenceBy(this.allChannels, this.userHeaderInfo, "id");
      // return this.allChannels.filter((item) => {
      //   return !this.userHeaderInfo.some((userItem) => {
      //     userItem.id === item.id;
      //   });
      // });
    },
  },
  methods: {
    async fetchAllCity() {
      const res = await fetchAllCitys();
      this.allChannels = res.data.data.channels;
      console.log(res);
    },
    addChannel(channel) {
      this.userHeaderInfo.push(channel);
    },
  },
};
</script>

<style scoped lang="less">
.channel-edit {
  .edit-btn {
    width: 100px;
  }
  .channel-item .text {
    font-size: 24px;
    color: #222;
    margin-top: 0;
  }
  /deep/.channel-item .van-grid-item__content {
    background-color: #f4f5f6;
  }
  /deep/.recommed-channel {
    .van-icon-plus {
      color: #222;
      font-size: 30px;
      margin-right: 5px;
    }
  }
  .channel-item {
    /deep/.van-icon-clear {
      font-size: 14px;
      position: absolute;
      right: -10px;
      top: -10px;
      // opacity: 0.3;
      color: #cacaca;
    }
    .active {
      color: red;
    }
    /deep/.van-grid-item__icon-wrapper {
      position: unset;
    }
  }
}
</style>
